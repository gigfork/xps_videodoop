package job;
import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.util.Arrays;
import java.util.Random;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;

public class generatePopulation
{
	void generate(int numReducers,int numNodes) throws IOException
	{		
		FileWriter fstream = new FileWriter("/home/user/Documents/out.txt");
		BufferedWriter out = new BufferedWriter(fstream);

		String[] array = new String[numNodes];
		for(int i=1;i<=numNodes;i++)
			array[i-1] = String.valueOf(i);
		
		String[] array_1 = new String[numNodes];

		Random rnd = new Random();
		int t1,t2;
		String t3;
		
		for(int i=1;i<=numReducers*400;i++)
		{
			array_1 = Arrays.copyOf(array, array.length);
			for(int j=1;j<=numNodes;j++)
			{
				t1 = rnd.nextInt(numNodes);
				t2 = rnd.nextInt(numNodes);
				t3 = array_1[t1];
				array_1[t1] = array_1[t2];
				array_1[t2] = t3;				
			}
			for(t1=0;t1<numNodes-1;t1++)
				out.append(array_1[t1]+",");
			out.append(array_1[t1]+'\n');
		}
		out.flush();
		out.close();
		
		String dst = "/user/user/user/rohit/input/vrp_input/pop/pop.txt";
		
		InputStream in = new BufferedInputStream(new FileInputStream("/home/user/Documents/out.txt"));
		Configuration conf = new Configuration();
		FileSystem fs = FileSystem.get(URI.create(dst), conf);
		OutputStream out1 = fs.create(new Path(dst));
		
		IOUtils.copyBytes(in, out1, 4096, true);		
	}
}
