package job;

import java.io.IOException;


import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.MapFile;
import org.apache.hadoop.mapred.JobConf;

public class calculateFitness {

	MapFile.Reader customerFile = null;
	MapFile.Reader trafficFile = null;
	IntArrayWritable atcust; // for CustomerMap
	IntArrayWritable attraf; // for trafficMap	
	public static int smooth,slow,delaying,stagnating;
	public static int numNodes,totveh,totcap,vehCount;
	int fit;
	
	
	public calculateFitness(MapFile.Reader customerFile1,MapFile.Reader trafficFile1,IntArrayWritable atcust1,IntArrayWritable attraf1) throws IOException {
		this.customerFile = customerFile1;
		this.trafficFile = trafficFile1;
		this.atcust = atcust1;
		this.attraf = attraf1;		
		
		atcust = new IntArrayWritable(6);
		customerFile.get(new IntWritable(-2),atcust);
		numNodes = atcust.get()[0].get();
		
		customerFile.get(new IntWritable(-1),atcust);
		
		totveh = atcust.get()[0].get();
		totcap = atcust.get()[1].get();
		
		attraf = new IntArrayWritable(numNodes);
	}
	
	
	String getSpeeds()
	{
		return new String(""+fit+'\t'+smooth+'\t'+slow+'\t'+delaying+'\t'+stagnating+'\t'+vehCount+"");
	}
	
	int getFitness(int[] value) throws Exception
	{	
		
		vehCount=0;delaying = 0;slow = 0;smooth = 0;stagnating = 0;
		
		int veh = 1;
		int cap = totcap;
		int fitness=0;
		
		vehCount++;
		vehicle obj = new vehicle(totcap);
		
		int last = 0;
		
		for(int i=0;i<value.length;i++)
		{				
			//System.err.println(totveh+"");
			obj = checkFeasibility(value,i,obj);
			if(obj.feasible);
			else
			{ 
				if(obj.lastInd!=-1)
					last = obj.lastInd;
				if(obj.error)break;
				if(vehCount<totveh)vehCount++;
				fitness += getTime(obj.lastInd,0, getDistance(obj.lastInd,0),obj);
				obj = new vehicle(totcap);
				if(vehCount<totveh)i--;
			}
		}		
		fitness += obj.fitness;
		
		if(fitness==0 || obj.error)
			return last;
		
		fit = fitness;
		double t = (long)100000/(double)fitness;
		t=t*t;
		fitness = (int)t;
		
		return fitness;
	}
	
	
	vehicle  checkFeasibility(int[] value, int ind, vehicle obj) throws Exception 
	{
		
		int i,j,t;
		double d;
		
		if(obj.lastInd==-1)
		{
			i=0;
			j = value[ind];	
			if(obj.cap<getDetails(j,3))
			{ //System.err.println("error -------");
				obj.error = true;
			}
		}
		else
		{
			i = value[ind-1];
			j = value[ind];			
		}
		
		if(obj.cap<getDetails(j,3))
			obj.feasible = false;
		else
		{
			d = getDistance(i, j);
			t = getTime(i, j, d,obj);
			//System.out.println(getDetails(j,5)+"   " +t);
			if(getDetails(j,5)>=t)
			{
				
				switch(attraf.get()[j].get())
				{
				case 1: smooth++;
				break;
				case 2: slow++;
				break;
				case 3: delaying++;
				break;
				case 4: stagnating++;
				break;
				}
				
				obj.time = t + getDetails(j,6)/60;
				obj.cap -= getDetails(j,3);
				obj.fitness = obj.time; //* obj.time; // power scaling
				obj.lastInd =j;
			}
			else
			{
				obj.feasible = false;
				if(i==0)
					obj.error = true;
				
			}
		}
		
		return obj;
	}
	   
	
	double getDistance(int i,int j) throws IOException
	{
		int x1,x2,y1,y2;
		x1 = getDetails(i,1);
		y1 = getDetails(i,2);
		
		x2 = getDetails(j,1);
		y2 = getDetails(j,2);
		
		return Math.sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
	}
	
	//customerMap
	int getDetails(int ind,int c) throws IOException
	{
		if(customerFile!=null){
		customerFile.get(new IntWritable(ind),atcust);
		return atcust.get()[c-1].get();}
		else return -1;
	}
	
	//Get Traffic between
	int getTime(int i,int j,double d,vehicle obj) throws IOException
	{
		trafficFile.get(new IntWritable(i),attraf);
		int readytime = getDetails(j,4);
		int t = obj.time+((int)d/(attraf.get()[j].get()*15))*60;
		
		
		if(readytime>t)
			return readytime;		
		return t;		
	}
	
	class vehicle
	{
		boolean feasible;
		double fitness;
		int cap;
		int time;
		int lastInd;
		boolean error;
		//int lastTraffic;
		
		vehicle(int c)
		{
			feasible = true;
			fitness = 0;
			cap = c;
			time=0;
			lastInd = -1;
			error = false;
		}
	}
	
	
	
	
}
