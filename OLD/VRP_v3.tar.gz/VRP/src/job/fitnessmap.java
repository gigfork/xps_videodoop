package job;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Random;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.MapFile;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.Counters.Counter;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;


@SuppressWarnings("deprecation")
public class fitnessmap extends MapReduceBase 
implements Mapper<LongWritable, Text, IntWritable, Text>
{
	MapFile.Reader customerFile = null;
	MapFile.Reader trafficFile = null;
	IntArrayWritable atcust; // for CustomerMap
	IntArrayWritable attraf; // for trafficMap
	JobConf conf ;
	calculateFitness cft;
	
	public void configure(JobConf conf){
		this.conf=conf;
		try
		{
			int i,j;
			Path[] cachefiles= DistributedCache.getLocalCacheArchives(conf);
			FileSystem fs = FileSystem.getLocal(new Configuration());
			
			if(cachefiles!= null && cachefiles.length > 0)
			{
				if(cachefiles[0].getName().equals("customerFile.map.tar.gz")){ i=0;j=1;}
				else {i=1;j=0;}
				customerFile = new MapFile.Reader(fs,cachefiles[i].toString()+"/customerFile.map",conf);
				trafficFile = new MapFile.Reader(fs,cachefiles[j].toString()+"/trafficFile.map",conf);
				cft = new calculateFitness(customerFile, trafficFile, atcust, attraf);
			}			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	@Override
	public void close() throws IOException
	{
		IOUtils.closeStream(customerFile);
		IOUtils.closeStream(trafficFile);
	}
	
	@Override
	public void map(LongWritable key, Text value,
			OutputCollector<IntWritable, Text> output, Reporter reporter) throws IOException {
		
		
		StringTokenizer token = new StringTokenizer(value.toString(),",");
		int[] array = new int[token.countTokens()];
		
		int i=0;
		while(token.hasMoreElements())
			array[i++] = Integer.parseInt(token.nextToken());
		
		int num = conf.getNumReduceTasks();
		Random rnd = new Random();		
		
		try {		
			i = cft.getFitness(array);			
			Counter counter = reporter.getCounter(vrp.myCounters.max_fitness);
			
			if(i>counter.getValue())
			{
				reporter.incrCounter(vrp.myCounters.max_fitness, -counter.getValue());
				reporter.incrCounter(vrp.myCounters.max_fitness, i);
			}
		
			output.collect(new IntWritable(rnd.nextInt(num)),new Text(value.toString()+'\t'+i));
			
		} catch (Exception e) {
			output.collect(new IntWritable(0),new Text(cft.getSpeeds()));
		}
		
	}
	
}
