package job;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Random;
import java.util.StringTokenizer;

import javax.swing.text.html.HTMLDocument.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;

public class generatePopulation
{
	
	int customer[][];
	int distance[][];
	int type[][];
	
	float speed[][];
	
	int numNodes,cap;
	
	public generatePopulation(int numNodes) throws Exception {
		
		this.numNodes = numNodes;
		FileInputStream fstream = new FileInputStream("/home/user/Documents/Hadoop Program  Data/VRP/copy.TXT");
		DataInputStream in = new DataInputStream(fstream);
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		
		customer = new int[numNodes][6];
		
		String line;
		StringTokenizer token;
		cap = Integer.parseInt(br.readLine());
		
		int i=0,j;
		while((line=br.readLine())!=null)
		{
			j=0;
			token = new StringTokenizer(line,"	");
			token.nextToken();
			while(token.hasMoreTokens())
				customer[i][j++] = Integer.parseInt(token.nextToken());
			i++;
		}
		generate_distance();
		get_speed();
		
		
	}
	
	void generate_distance() throws Exception
	{
		FileWriter fstream = new FileWriter("/home/user/Documents/Hadoop Program  Data/VRP/type.txt");
		BufferedWriter out = new BufferedWriter(fstream);		
		Random rnd = new Random();		
		
		distance = new int[numNodes][numNodes];
		type = new int[numNodes][numNodes];
		for(int i=0;i<numNodes;i++)
		{
			for(int j=i;j<numNodes;j++)
			{
				if(i==j)
				{
					distance[i][j]=0;
					type[i][j] = 0;
				}
				else
				{
					distance[i][j]=distance[j][i]= (int) Math.sqrt((customer[i][0] - customer[j][0])*(customer[i][0] - customer[j][0]) + (customer[i][1] - customer[j][1])*(customer[i][1] - customer[j][1]));
					type[i][j]=type[j][i] = rnd.nextInt(5)+1;
					out.append(type[i][j]+",");
				}
			}
			out.append('\n');
		}
		out.close();
		fstream.close();
	}
	
	void get_speed() throws IOException
	{
		 FileInputStream fstream = new FileInputStream("/home/user/Documents/Hadoop Program  Data/VRP/speed.txt");
		 DataInputStream in = new DataInputStream(fstream);
		 BufferedReader br = new BufferedReader(new InputStreamReader(in));
		 String line;
		 
		 speed = new float[6][5];
		 StringTokenizer token;
		 
		 int i=1,j=1;
		 
		 while((line=br.readLine())!=null)
		 {
			 j=1;
			 token = new StringTokenizer(line);
			 while(token.hasMoreTokens())
				 speed[i][j++]=Float.parseFloat(token.nextToken());
			 i++;			 
		 }		 
	}
	
	public void generate(int numReducers) throws IOException
	{		
		FileWriter fstream = new FileWriter("/home/user/Documents/Hadoop Program  Data/VRP/pop_out.txt");
		BufferedWriter out = new BufferedWriter(fstream);

		int[] array = new int[numNodes];
		for(int i=1;i<numNodes;i++)
			array[i-1] = i;
		
		int[] array_1 = new int[numNodes];

		Random rnd = new Random();
		int t1=0,t2,t3;
		
		// 1/3 Random
		
		for(int i=1;i<=numReducers*30;i++)
		{
			array_1 = Arrays.copyOf(array, array.length);
			for(int j=1;j<numNodes;j++)
			{
				t1 = rnd.nextInt(numNodes);
				t2 = rnd.nextInt(numNodes);
				t3 = array_1[t1];
				array_1[t1] = array_1[t2];
				array_1[t2] = t3;			
			}
			
			if(i>numReducers*10 && i<numReducers*20)
				out.append(savings_generate(array_1));
			else if(i>=numReducers*20);
			else			
				for(t1=0;t1<numNodes-1;t1++)
					out.append(array_1[t1]+",");
			
			out.append(""+array_1[t1]+'\n');
		}
		out.flush();
		out.close();
		
		String dst = "/user/user/user/rohit/input/vrp_input/pop.txt";
		
		InputStream in = new BufferedInputStream(new FileInputStream("/home/user/Documents/Hadoop Program  Data/VRP/pop_out.txt"));
		Configuration conf = new Configuration();
		FileSystem fs = FileSystem.get(URI.create(dst), conf);
		OutputStream out1 = fs.create(new Path(dst));		
		IOUtils.copyBytes(in, out1, 4096, true);
	}
	
	String savings_generate(int[] array)
	{
		ArrayList<ArrayList<Node>> routes = new ArrayList<ArrayList<Node>>();
		ArrayList<Node> tmp = null;
		Node n=null,m=null;		
		boolean[] taken = new boolean[numNodes];
		int time;
		
		
		
		for(int i=1;i<array.length;i++)
		{
			if(!taken[i])
			{
				if(tmp!=null) routes.add(tmp);
				tmp = new ArrayList<Node>();
				n = new Node(array[i]);
				
				n.time_dep = customer[n.value][3]+customer[n.value][5];
				n.cap_left -= customer[array[i]][2];
				tmp.add(n);		
				taken[array[i]] = true;
			}
			for(int j=i+1;j<array.length;j++)
			{
				if(!taken[j])
				{
					time = check_feasibility(tmp.get(tmp.size()-1),j);
					if(time!=-1)
					{
						m = new Node(j);
						m.cap_left = n.cap_left - customer[j][2];
						m.time_dep = time+customer[j][5];
						tmp.add(m);
						taken[j] = true;
						n=m;
					}				
				}
			}
		}
		if(tmp!=null)routes.add(tmp);
		
		StringBuffer s= new StringBuffer();
		
		for(int i=0;i<routes.size();i++)
		{
			tmp = routes.get(i);
			for(int j=0;j<tmp.size()-1;j++)
				s.append(tmp.get(j).value+",");
			s.append(tmp.get(tmp.size()-1).value);
		}
		return s.toString();
	}
	
	int check_feasibility(Node n,int j)
	{
		int time;
		if(n.time_dep > customer[j][4] || n.cap_left < customer[j][2] ) return -1;
		else
		{
			time = getTime(n, j);
			if(time>customer[j][4] || time==-1)
				return -1;
			else 
				return time;
		}			
	}
	
	int getTime(Node n,int j)
	{
		
		int div = customer[0][4]/4;
		int typer = type[n.value][j];
		int zone = (int)(n.time_dep/div)+1;		
		
		int dist = distance[n.value][j];	
		int ctime = n.time_dep;
		
		
		while(dist!=0 && zone<= type[1].length)
		{
			if((((zone*div)-ctime)*speed[typer][zone])>=dist)
				return ctime + (int)(dist/speed[typer][zone]);
			else
			{
				dist-=((zone*div)-ctime)*speed[typer][zone];
				ctime = (zone*div);
				zone++;
			}
		}
		return -1;
	}
	
	class Node
	{
		int value;
		int time_dep;
		int cap_left;
		
		public Node(int v) {
			value = v;
			time_dep = 0;
			cap_left = cap;
		}
	}

}
