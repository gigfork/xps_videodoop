package job;

import java.io.IOException;
import java.util.Random;
import java.util.StringTokenizer;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.MapFile;

public class crossover {	
	
	MapFile.Reader customerFile = null;
	MapFile.Reader trafficFile = null;
	IntArrayWritable atcust; // for CustomerMap
	IntArrayWritable attraf; // for trafficMap	
	
	public crossover(MapFile.Reader customerFile,MapFile.Reader trafficFile,IntArrayWritable atcust,IntArrayWritable attraf) throws IOException {
		this.customerFile = customerFile;
		this.trafficFile = trafficFile;
		this.atcust = atcust;
		this.attraf = attraf;
	}	
	
	public String doCrossover(String can1,String can2) throws IOException 
	{	
		return MOX(toArray(can1),toArray(can2));
	
	}
	
	//modified order crossover	//smallest Distance
	String MOX(int[] can1,int[] can2) throws IOException
	{
		Random rnd = new Random();
		
		int point1 = cord_smallest_time(can2);
		int point2 = rnd.nextInt(can2.length);
		if(point2<point1)
			point2 +=(can2.length-1-point1);	
		
		boolean[] find = new boolean[can1.length+1];
		for(int i=point1;i<=point2;i++)
			find[can2[i]] = true;
		
		for(int i=0,j=0;i<can1.length && j<can2.length;i++)
		{
			if(j>=point1 && j<=point2 && point2!=can2.length-1)
				j = point2+1;
			
			if(!find[can1[i]])
				can2[j++] = can1[i];
		}
		return tostring(mutate(can2));
	}
	
	
	int[] mutate(int[] can)
	{
		int t=100;
		
		Random rnd = new Random();
		rnd.nextInt(100);
		
		if(t<25)
		{
			int i = rnd.nextInt(can.length);
			int j = rnd.nextInt(can.length);
			
			t = can[i];
			can[i] = can[j];
			can[j] = t;
			return can;
		}
		return can;
	}
	
	int[] toArray(String str)
	{
		StringTokenizer token = new StringTokenizer(str,",");
		int[] array = new int[token.countTokens()];
		int i=0;
		while(token.hasMoreTokens())
			array[i++] = Integer.parseInt(token.nextToken());
		return array;
	}

    String tostring(int[] can)
    {
    	StringBuffer buf = new StringBuffer();
    	int i;
    	for(i=0;i<can.length-1;i++)
    		buf.append(can[i]+",");
    	buf.append(can[i]);
    	return buf.toString();
    }
	
	boolean find(int[] can,int i,int j,int num)
	{
		for(int k=i;k<=j;k++)
			if(can[k]==num)
				return true;
		return false;
	}
	
	int cord_smallest_time(int[] can) throws IOException
	{
		int min = Integer.MAX_VALUE;
		int time,ind=0;
		
		for(int i=0;i<can.length-1;i++)
		{
			time = getTime(can[i],can[i+1],getDistance(can[i],can[i+1]));
			if(time<min)
			{
				min = time;
				ind = i;				
			}
		}
		return ind;
	}
	
	double getDistance(int i,int j) throws IOException
	{
		int x1,x2,y1,y2;
		x1 = getDetails(i,1);
		y1 = getDetails(i,2);
		
		x2 = getDetails(j,1);
		y2 = getDetails(j,2);
		
		return Math.sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
	}
	
	int getDetails(int ind,int c) throws IOException
	{
		if(customerFile!=null){
		customerFile.get(new IntWritable(ind),atcust);
		return atcust.get()[c-1].get();}
		else return -1;
	}

	int getTime(int i,int j,double d) throws IOException
	{
		trafficFile.get(new IntWritable(i),attraf);
		int t = ((int)d/(attraf.get()[j].get()*15))*60;	
		return t;		
	}	
}
